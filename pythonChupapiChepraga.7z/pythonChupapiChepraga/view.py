import connect
from connect import connection
import sql_queries

try:
    with connection.cursor() as cursor:
        cursor.execute("select * from category_pets_view")
        view1 = cursor.fetchall()
        print("Список животных по категориям:")
        for i in view1:
            print(f"Категория: {i['name']}, | кличка: {i['nickname']}, | возраст: {i['age']} , цена: {i['price']} ")

        print("_" * 20)
        cursor.execute("select * from Check_Customer_View")
        view2 = cursor.fetchall()
        print("Продажи:")
        for y in view2:
            print(
                f"Дата: {y['date']}, | Способ оплаты: {y['payment_type']}, | Имя: {y['first_name']},| Фамилия: {y['last_name']} ")

            print("_" * 20)

        cursor.execute("select * from max_pets ")
        view3 = cursor.fetchall()
        print("Самые дорогие:")
        for e in view3:
            print(f"Кличка: {e  ['nickname']}, | Порода: {e['breed']}, | Цена: {e['pets']} ")

            print("_" * 20)

        cursor.execute("select * from most_pets")
        view4 = cursor.fetchall()
        print(f"Больше всего питомцев в категории: {view4[0]['most_pets']}")


finally:
    connection.close()

