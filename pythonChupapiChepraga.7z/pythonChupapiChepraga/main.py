import pymysql
import sql_queries
from config import host, user, password, db_name


# Обработка исключений
try:
    # Подключение к базе данных при помощи connect()
    connection = pymysql.connect(
       host=host,
       port=3306,
       user=user,
       password=password,
       database=db_name,
       cursorclass=pymysql.cursors.DictCursor
    )
    print('Successfully connected...')
    print("#" * 20)

    try:
        with connection.cursor() as cursor:
            # создание таблицы Categ
            cursor.execute(sql_queries.create_table_categ)
            connection.commit()
            # создание таблицы Pets
            cursor.execute(sql_queries.create_table_pets)
            connection.commit()
            #создание таблицы Pets
            cursor.execute(sql_queries.create_table_custom)
            connection.commit()
            cursor.execute(sql_queries.create_table_basket)
            connection.commit()
            cursor.execute(sql_queries.create_table_cheque)
            connection.commit()
            cursor.execute(sql_queries.create_table_sales)
            connection.commit()
            cursor.execute(sql_queries.view_petcategory)
            connection.commit()



    finally:
            connection.close()

except Exception as ex:
   print('Connection refused...')
   print(ex)







