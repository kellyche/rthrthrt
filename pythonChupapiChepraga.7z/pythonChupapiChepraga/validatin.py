import re
import phonenumbers
from validate_email import validate_email

def is_valid_password(password):
    # Проверьте, что пароль состоит как минимум из 8 символов и содержит как минимум одну заглавную букву, одну строчную букву и одну цифру.
    if re.match(r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,20}$", password):
        return True
    else:
        return False

def is_valid_email(email):
    # проверка email на валидность
    if validate_email(email):
        return True
    else:
        return False

def is_valid_phone_number(phone_number):
    try:
        parsed_number = phonenumbers.parse(phone_number)
        return phonenumbers.is_possible_number(parsed_number) and phonenumbers.is_valid_number(parsed_number)
    except phonenumbers.phonenumberutil.NumberParseException:
        return False

def validate_login(login):
    if len(login) < 4 or len(login) > 10:
        return False
    return True





