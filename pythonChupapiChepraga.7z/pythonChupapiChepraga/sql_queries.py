create_table_category = "CREATE TABLE `Category` (id int AUTO_INCREMENT," \
                        " name varchar(32)," \
                        " description varchar(32)," \
                        " PRIMARY KEY (id));"

create_table_pets = "CREATE TABLE `Pets` (id int AUTO_INCREMENT," \
                     " nickname varchar(32)," \
                     " age int," \
                     " gender varchar(32)," \
                     " breed varchar(32)," \
                     " price decimal(10, 2)," \
                     " img blob," \
                     " description varchar(32)," \
                     " category_id INT,"\
                     " PRIMARY KEY (id),"\
                     " FOREIGN KEY (category_id) REFERENCES Category(id));"

create_table_custom = "CREATE TABLE `Customer` (id int AUTO_INCREMENT," \
                    " first_name varchar(32)," \
                    " last_name varchar(32)," \
                    " email varchar(32)," \
                    " phone varchar(32)," \
                    " passport varchar(32)," \
                    " login varchar(32)," \
                    " password varchar(32)," \
                    " PRIMARY KEY (id));"

create_table_basket = "CREATE TABLE `Basket` (id int AUTO_INCREMENT," \
                     " customer_id INT," \
                     " pet_id INT," \
                     " quantity int," \
                     " PRIMARY KEY (id),"\
                     " FOREIGN KEY (customer_id) REFERENCES Customer(id),"\
                     " FOREIGN KEY (pet_id) REFERENCES Pets(id));"

create_table_cheque = "CREATE TABLE `Cheque` (id int AUTO_INCREMENT," \
                     " date DATE," \
                     " payment_type VARCHAR(32)," \
                     " customer_id INT," \
                     " PRIMARY KEY (id),"\
                     " FOREIGN KEY (customer_id) REFERENCES Customer(id));"

create_table_sales = "CREATE TABLE `Sales` (id int AUTO_INCREMENT," \
                     " check_id int," \
                     " basket_id int," \
                     " quantity int," \
                     " PRIMARY KEY (id),"\
                     " FOREIGN KEY (check_id) REFERENCES Cheque(id),"\
                     " FOREIGN KEY (basket_id) REFERENCES Basket(id));"

insert_category = "INSERT INTO 'Category' (name, description) VALUES" \
               "('Собака', 'Гампр')," \
               "('Кошка', 'Египетская')," \
               "('Птица', 'Мадагаскарский попугай');"

insert_pets = "INSERT INTO pets (nickname, age, gender, breed, price, img, description, category_id) VALUE" \
              "('Пихцик', 3, 'Мужской', 'Сибирская', 500.00, NULL, 'Лучший друг', 1), "\
              "('Клирка', 2, 'Женский', 'Бульдог', 300.00, NULL, 'Заботливая', 2), "\
              "('Пулика', 1, 'Женский', 'Красный', 50.00, NULL, 'Послушная', 3); "\

insert_customer = "INSERT INTO Customer (first_name, last_name, email, phone, passport, login, password), VALUE" \
                  "('Бадасян', 'Эдмонд', 'gggppp@example.com', '544-3341', '123456789', 'gggppp', 'pass1234')," \
                  "('Бацаев', 'Абдула', 'ooottt@example.com', '544-6479', '987654321', 'ooottt', 'pass9876');"\

insert_basket = "INSERT INTO Basket (customer_id, pet_id, quantity) VALUES " \
                "(1, 1, 2), " \
                "(1, 2, 1), " \
                "(2, 3, 3);"

insert_cheque = "INSERT INTO Cheque (date, payment_type, customer_id) VALUES " \
                "('2023-05-15', 'Кредитной картой', 1) " \
                "('2023-05-11', 'Наличными', 2);"

insert_sales = "INSERT INTO Sales (check_id, basket_id, quantity) VALUES " \
                "(1, 1, 2), " \
                "(1, 2, 1), " \
                "(2, 3, 3);"

view_List_of_pets_by_category = "Create View  category_pets_view  as select category.name, pets.nickname, pets.price, " \
                                "pets.age from Category INNER JOIN pets ON category.id=pets.category_id;"

view_List_of_receipts_and_customers = "CREATE VIEW `Check_Customer_View` AS SELECT Cheque.id, Cheque.date, Cheque.payment_type, Customer.first_name, Customer.last_name FROM Cheque INNER JOIN Customer ON Cheque.customer_id = Customer.id;"

view_The_most_expensive_pet = "Create View  max_pets  as select nickname, breed, MAX(price) as pets From Pets "

view_Category_with_the_most_pets = "Create View  most_pets as select  MAX(name) as most_pets From Category"


